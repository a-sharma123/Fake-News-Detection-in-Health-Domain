
# Constants

GET_RETWEET = "get_retweet"
GET_TWEET = "get_tweet"
GET_FOLLOWERS_ID = "get_followers_ids"
GET_FRIENDS_ID = "get_friends_ids"
GET_USER = "get_user"
GET_USER_TWEETS = "get_user_tweets"



# User Info
USER_ID = 'user_id'
FOLLOWERS = 'followers'
FOLLOWING = 'following'
